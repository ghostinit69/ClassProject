﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GamePalace.Models
{
    public class GameFavorite
    {
        public int GameFavoriteId { get; set; }
        public int GameId { get; set; }
        public string UserId { get; set; }
    }
}
