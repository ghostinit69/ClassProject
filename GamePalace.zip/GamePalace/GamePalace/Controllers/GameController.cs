﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using Microsoft.AspNetCore.Identity;
using GamePalace.Data;

namespace GamePalace.Controllers
{
    public class GameController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GameController(ApplicationDbContext GameContext)
        {
            _context = GameContext;

        }
        public IActionResult PlayGameById(int id)
        {

            return View(_context.Games.Where(x=>x.GameId == id).FirstOrDefault());
        }        
    }
}